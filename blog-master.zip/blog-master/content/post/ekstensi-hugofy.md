---
title: "Coba-coba Ekstensi Hugofy di VS Code"
slug: ekstensi-hugofy
date: 2017-12-19T23:20:33+08:00
draft: false

image: "/img/hugofy/install-hugofy.png"
description: "Penasaran dengan ekstensi ini. Lansung saja saya coba install."
---

Penasaran dengan ekstensi ini. Lansung saja saya coba install.

![Ekstensi Hugofy di VS Code](/img/hugofy/install-hugofy.png)

Pada deskripsinya menjelaskan...

...dengan ekstensi ini, kita bisa:

1. Buat web hugo baru
2. Buat artikel
3. Build site
4. Menajalankan server dan mematikannya
5. Download Tema


Ekstensi Hugofy ini bisa kita gunakan dengan menekan tombol
`Ctrl`+`Shift`+`p` lalu mengetik `hugofy` dan memilih
perintah yang ingin dijalankan.

![Perintah Hugofy](/img/hugofy/perintah-hugofy.png)

Tapi begitu saya coba menjalankan server, 
terjadi error seperti ini:

![Erro menjalankan server](/img/hugofy/error-server.png)

Sebagian dari perintah-perintah Hugofy sudah biasa
saya ketik lewat terminal.

Jadi saya memutuskan untuk uninstall saja,
karena lebih cepat rasanya lewat terminal.

Mungkin buat yang belum terbiasa menggunakan terminal
bisa mencobanya.

Kalau saya sih lebih suka pakai terminal.