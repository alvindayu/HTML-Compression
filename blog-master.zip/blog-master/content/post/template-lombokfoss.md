---
title: "Template Baru untuk Lombokfoss"
slug: template-lombokfoss
date: 2017-12-21T16:03:55+08:00
draft: false

tags:
    - Blog
    - Hugo

image: "/img/lombokfoss/single.png"
description: "Setelah membuat template untuk blog ini.
Sekarang giliran blog Lombokfoss yang saya buatkan templatenya."
---

Setelah membuat template untuk blog ini.
Sekarang giliran blog Lombokfoss yang saya buatkan templatenya.

Pengerjaannya sangat cepat, cuma 1 hari. Karena
saya _copas_ dari [template blog ini](https://github.com/ardianta/blog/tree/master/themes/pargo). Lalu tinggal 
dimodif dan diatur tata letaknya.

Maka jadilah seperti ini.

Halaman home:

![Halaman Home Lombokfoss](/img/lombokfoss/home.png)

Halaman artikel:

![Halaman Artikel Lombokfoss](/img/lombokfoss/single.png)

Seperti biasa, untuk tampilan saya masih mengandalkan Bootstrap 4.

Template ini masih belum selesai.

## Pekerjaan Selanjutnya

- [x] Perbaiki tampilan untuk mobile 
- [x] ~~Pasang Komentar Faceook~~ _(diganti pakai disqus)_
- [x] Pasang Komentar Disqus
- [x] Menambahkan Google Analytic _(pakai Cloudflare)_
- [x] Menambahkan Open Graph
- [ ] Menambahkan Share Button
- [ ] Mendaftarkan ke Google Webmaster
- [ ] Perbaiki Kualitas Konten
- [x] Pembuatan halaman 404.html _(404 dari Netlify)_
- [x] Template untuk halaman tags
- [ ] Optimasi dan perbaikan