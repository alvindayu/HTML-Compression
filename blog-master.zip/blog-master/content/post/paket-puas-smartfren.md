---
title: "Paket Puas Smartfren Nggak Bikin Puas!"
slug: paket-puas-smartfren
date: 2019-02-24T00:06:44+08:00
draft: false

type: post

tags:
    - Smarfren

image: ""
description: "Sejauh pengalaman saya, setelah habis FUP rasanya seperti menggunakan internet zaman dulu (3G) yang kecepatannya sangat lambat sekitar 16kB/s."
---

Sinyal smartfren termasuk yang cukup stabil di rumah saya.
Saya sudah mencoba beberapa operator seperti XL dan Telkomsel,
tapi sinyalnya kurang stabil.

XL, kalau mati lampu langsung down...

Sinyal 4G yang cuma 1 bar itu langsung hilang,
dan akan beralih ke sinyal 2G.

Saya sebenarnya sudah lama pakai Smartfren---sejak
zaman modem USB, MiFi, Hingga Andromax Prime dan Wi Box---
bukan berarti ngefans banget sama Smartfren.

Melainkan karena cuma dia aja yang stabil sinyalnya, 
apalagi saat ini Smarfren mau ngambil frekuensinya Bolt.

Selain itu, harga paketnya relatif lebih murah.
Salah satu paket yang saya suka adalah paket Unlimited.

Sampai bela-belain buat beli hp Andromax Prime
cuma buat beli paket itu. Hehe...

Ya, saya suka yang tanpa batas. Eh tapi
ada batasnya yaitu FUP.

Oh iya ngomong-ngomong tentang paket Unlimited,
Si Andromax Prime ini di-bundle dengan paket **Puas**.

Yaitu paket unlimited dengan kuota FUP 1GB selama
satu bulan + bonus SMS dan Nelfon. 
Setelah habis yang 1GB, maka kecepatan akan diturunkan.

Ini yang bikin tidak **Puas**.

Sejauh pengalaman saya, setelah habis FUP
rasanya seperti menggunakan internet zaman dulu (3G)
yang kecepatannya sangat lambat sekitar 16kB/s.

Saya lebih merekomendasikan menggunakan paket
yang **True Unlimied**. Karena kuota FUP-nya
akan diberikan 1GB setiap hari, bukan 1GB untuk
satu bulan.

Paket ini cukup lumayan untuk mendengarkan podcast
dan streaming musik dan nelfon di aplikasi chat.

## Dari Paket Puas ke True Unlimited

Sebelum beralih ke paket True Unlimited,
ada beberapa hal yang ingin saya bagikan:

Pertama, paket Puas tidak bisa di-nonaktifkan
melalui aplikasi MySmartfren. Katanya,
kita harus ke galery Smartfren untuk
menonaktifkannya.

Kedua, Andromax akan mengubah pulsa
secara otomatis menjadi paket puas.

Artinya, setiap pengisian pulsa,
maka pulsa tersebut akan diubah
otomatis menjadi paket Puas.

Cara menghentikan hal ini adalah
dengan mengirim SMS ke `123`
yang berisi `convert off`.

![Convert Off](/img/smartfren/convertoff.png)

Setelah itu, kita akan mendapatkan SMS
balasan dari `888` yang berisi seperti ini.

![Convert Off](/img/smartfren/888.png)

Barulah setelah itu, kita bisa mendaftar paket
True Unlimited...

Eh tapi masih ada paket Puas, gimana donk?

Nggak apa-apa, bisa juga pakai dua paket sekaligus.
Yang akan terpakai adalah True Unlimited.

## #2019 Ganti ISP

Pinginnya sih pakai [indihome](https://indihome.co.id/) atau [XL Home](http://lebihpow.com/) di rumah biar puas, tapi
sayangnya kabel serat optik belum masuk di desa saya.

fufufu...

Tapi kita tunggu saya, karena kemarin di hari Jum'at
Indonesia sudah meluncurkan satelit baru yaitu Nusantara Satu.

Mudah-mudahan nanti bisa jadi solusi internet murah
di pelosok.