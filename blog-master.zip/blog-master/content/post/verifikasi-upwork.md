---
title: "Verifikasi Profil Upwork via Video Chat"
slug: verifikasi-upwork
date: 2018-01-31T10:52:18+08:00
draft: false

type: post

tags:
    - Upwork
    - Freelance

image: "/img/upwork/upwork-akun.png"
description: "Hari ini saya melakukan verifikasi profil upwork 😄..."
---

Hari ini saya melakukan verifikasi profil upwork 😄...

Sebenarnya saya sudah daftar upwork sejak era Odesk dan Elance 
masih berjaya, namun belum pernah melakukan apa-apa.

Nah kemarin dapat kebetulan job pertama bikin 
pop-up dengan [vex](http://github.hubspot.com/vex/docs/welcome/) untuk [Hugo](https://gohugo.io/).

...dan beberapa hari berikutnya dapat email dari Upwork
yang mengatakan: akun saya sementara ditahan dan harus
melalkukan verifikasi melalui video chat.

Video chat!!

Ini terdengar sulit bagi saya. Karena 
beberapa waktu yang lalu pernah video chat via skype
dengan orang inggris.

Masalahnya:

Saya paham apa yang ia katakan, tapi dia tidak paham
saat saya ngomong 😆. Karena saya belum terbiasa
berbahasa inggris.

Hal yang sama terjadi hari ini...

Saya ditanya "What is undefined variabel in Javascript?" 
jawabannya malah ngawur 😆.

Lalu tiba-tiba video chat terputus.

Namun, pada akhirnya...

Profil saya kembali aktif dan sudah bisa 
submit proposal lagi.

![Email dari Upwork](/img/upwork/upwork-akun.png)