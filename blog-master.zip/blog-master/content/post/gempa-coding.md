---
title: "Gempa Bumi di Lombok dan Coding"
slug: gemba-coding
date: 2018-07-29T10:14:57+08:00
draft: false

type: post

tags:
    - gempa

image: "/img/gempa/korban-gempa.png"
description: "Pagi ini (Minggu, 29 Juli 2018) Lombok diguncang gempa 6 SR."
---

**Minggu, 29 Juli 2018**. Pagi ini Lombok diguncang gempa 6 SR.

Saat itu, saya masih tertidur...

...dan dibangunkan oleh gempa ini.

Laptop saya masih menyala, karena semalam
tiduran sambil ngoding.

Menyelesaikan [tugas submission 4 dari Dicoding](https://www.dicoding.com/academies/55?course_ref=d281eb5ab90780db6a0502bc).

Android Studio masih terbuka...

Menampilkan baris-baris kode Kotlin.

Gempa makin besar!

Yang saya pikirkan pertama kali saat itu:

"Bagaimana nih menyelamatkan laptop saya"

Haha, keselamatan sendiri tidak dipikirkan.

Sementara ibu saya sudah berteriak menyuruh saya keluar.

Ya sudah, tutup saja laptopnya!

Lalu kabur...!!

Setelah beberapa menit kemudian gempanya selesai.

Saya kembali ke kamar dan memeriksa laptop.

Internet masih menyala, langsung saya googling
dengan kata kunci "gempa bumi".

![Gempa Bumi di Lombok](/img/gempa/google-gempa.png)

Yang keluar langsung informasi tentang gempa
di NTB.

Hebat!

Dari mana Google mendapatkan informasi secepat itu.

Ketika saya menulis ini (10:30 AM), 
Gempa masih terasa.

Yak! saya bisa melihatnya dari getaran 
secangkir kopi di samping saya.

Biasanya, gempa yang pernah saya alami hanya ternjadi 
satu kali saja...

...Namun, gempa kali ini berkali-kali.

Berdasarkan kabar yang beredar, gempa sudah terjadi
31 kali:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2290313260986033&width=500" width="500" height="491" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Saat ini saya masih merasa aman, karena tidak ada dampak yang diakibatkan gempa.

Namun...

Sepertinya Gempa ini berdampak besar di Lombok Timur dan Lombok Utara.

Melihat foto-foto korban dan dampak gempa di timeline,
membuat saya menjadi sedikit waspada.

Karena saat ini saya tinggal di rumah tua yang umurnya sudah
18 tahun.

![Korban Gempa](/img/gempa/korban-gempa.png)

Melihat foto-foto ini, saya jadi ikut merasakan duka...

...kehilangan orang-orang yang kita sayangi memang menyedihkan.

Namun.

Inilah ujian.

***Inalillahiwainahilahirojiun...***

Update: 30 Juli 2018

<blockquote class="twitter-tweet" data-lang="en"><p lang="in" dir="ltr">Hingga hari ini pukul 10.00 WIB telah terjadi 280 kali <a href="https://twitter.com/hashtag/gempa?src=hash&amp;ref_src=twsrc%5Etfw">#gempa</a> susulan.<br>Selalu ikuti informasi perkembangan gempa melalui akun <a href="https://twitter.com/infoBMKG?ref_src=twsrc%5Etfw">@infoBMKG</a> dan jangan mudah percaya dengan berita <a href="https://twitter.com/hashtag/Hoax?src=hash&amp;ref_src=twsrc%5Etfw">#Hoax</a> yang mengatasnamakan <a href="https://twitter.com/hashtag/BMKG?src=hash&amp;ref_src=twsrc%5Etfw">#BMKG</a>.<a href="https://twitter.com/hashtag/Lombok?src=hash&amp;ref_src=twsrc%5Etfw">#Lombok</a> <a href="https://twitter.com/hashtag/PrayForLombok?src=hash&amp;ref_src=twsrc%5Etfw">#PrayForLombok</a></p>&mdash; BMKG (@infoBMKG) <a href="https://twitter.com/infoBMKG/status/1023778173777993729?ref_src=twsrc%5Etfw">July 30, 2018</a></blockquote>
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
