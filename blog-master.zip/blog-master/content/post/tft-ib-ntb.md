---
title: "Pengalaman Ikut TFT Indonesia Bijak NTB"
slug: tft-ib-ntb
date: 2018-11-25T20:41:52+08:00
draft: false

type: post

tags:
    - workshop
    - komunitas

image: "/img/workshop/tft/tft-ntb.jpeg"
description: "Acara ini merupakan pelatihan membuat konten positif semacam meme untuk melawan hoax."
---

Hari Sabtu sampai minggu tanggal 24--25 November 2018, saya mengikuti acara TFT (Training For Trainee) Indonesia Bijak NTB.

Acara ini merupakan pelatihan membuat konten positif semacam meme untuk melawan hoax.
Acara ini berlangsung seru, dan bayak wawasan baru yang bisa didapatkan dari sana.

Salah satu yang membuat saya tertarik adalah data tinggat literasi
yang ditampilkan pemateri.

Di sana Indonesia berada di urutan ke-60 dari 61 negara.

Menurut saya, ini yang menyebabkan berita hoax cepat menyebar di Indonesia.

Meme dan berita hoax lebih cepat dan gambang dicerna dibandingkan buku.

Oleh sebab itu, untuk melawan meme negatif atau konten negatif
di internet, Kita harus menciptakan konten-konten yang positif.

![TFT IB NTB](/img/workshop/tft/tft-ntb.jpeg)

## Apa yang didapatkan di acara TFT ini?

Yang pertama dapat ilmu tentang cara buat meme dan konten video.
Lalu dapat teman baru.

...dan tentunya dapat makan-makan gratis dan kaos. Hehehe.

## Kendala Saat Mengikuti Acara TFT

Saya sariawan, sehingga kurang enak saat makan. Haha

Batrai laptop saya rusak, gak bisa nyala.
Batray 0% gak bisa dicas.

Mungkin karena kemarin lupa dicas seharian full.

## Tugas Kelompok

Di acara ini, kita dibuatkan kelompok untuk membuat video.
Hasilnya diupload ke instagram dengan hastag [#indonesiabijakntb](https://www.instagram.com/explore/tags/indonesiabijakntb/).

...dan berikut ini adalah ahsil karya kelompok saya.

{{< instagram BqlTMSoACn8 >}}

## Akhir kata...

Udah... itu saja dulu.

Nanti ditambahkan lagi kalau ada.