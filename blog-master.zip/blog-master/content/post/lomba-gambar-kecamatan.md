---
title: "Lomba Gambar Tingkat Kecamatan"
slug: lomba-gambar-kecamatan
date: 2018-05-12T22:55:39+08:00
draft: false

type: post

tags:
    - nostalgia
    - menggambar

image: "/img/lomba-gambar/melukis-di-mypaint.png"
description: "Dulu saat SD pernah ikut lomba gambar tingkat kecamatan di acara 17-an. Peserta cuma dua orang, saya dan seseorang yang tidak saya kenal."
---

Dulu saat SD pernah ikut lomba gambar tingkat kecamatan di acara 17-an.
Peserta cuma dua orang, saya dan seseorang yang tidak saya kenal.

Kami disuruh menggambar tentang suasana desa. 

Waktu itu saya menggambar sawah dengan pensil.

Sementara dia menggunakan cat air.

Hasilnya:

- Juara 1: Dia
- Juara 2: Saya

Saya memang mengakui keahliannya...

Saya hanya bisa kagum melihat hasil lukisannya.

Sementara punya saya jelek dan apa adanya 😄...

Saat lomba, saya tidak pernah ngomong dengannya.
Karena belum saling kenal.

Namun, sejak saat itu...

...dia menginspirasi saya untuk mencoba cat air.

Setelah lomba, saya akhirnya membeli kuas dan cat air.
Lalu mencoba sendiri.

Hasilnya jelek! 😄

Ternyata susah.

Waktu itu saya belum tahu apa-apa tentang cat air.
Kertas yang saya gunakan pun bukan kertas untuk cat air.

Hasilnya kertas kadang sobek, karena basah. haha...

Sekarang saya coba menggmabar lagi dengan cat air.
Tapi melalui komputer.

Hasilnya:

![Menggambar dengan cat air di MyPaint](/img/lomba-gambar/melukis-di-mypaint.png)

Lumayan, meskipun banyak kesalahan. Hehe

Saya butuh belajar dan latihan lagi.

Yang menjadi pertanyaan sekarng:

Bagaimana nasip anak itu ya? 

apakah dia sudah jadi seorang seniman atau belum?

Andai saja dulu saya kenal.