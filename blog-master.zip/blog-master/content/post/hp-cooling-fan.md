---
title: "Memperbaiki Laptop HP: COOLING FAN (902) ERROR"
slug: hp-cooling-fan
date: 2015-06-06T23:44:45+08:00
draft: false

tags:
    - laptop

image: ""
description: ""
---

_(ini adalah tulisan impor dari [blog lama](http://imtkj.blogspot.co.id/2015/06/memperbaiki-laptop-hp-cooling-fan-902.html))_

Ceritanya ada sebuah laptop (HP Mini) milik rekan bapak saya, setiap kali dihidupkan muncul pesan __"COOLING FAN (902) ERROR"__.

Saya coba masuk ke BIOS, tidak bisa.

Akhirnya saya membongkarnya.

Menurut pendapat saya, mungkin baterai CMOS-nya perlu di cabut supaya 
konfigurasi BIOS-nya di-reset.

Setelah membongkar dan mencabut baterai CMOS, mesih saja belum bisa.

Belum mau menyerah, selanjutnya saya cari solusi di Google dan menemukan viedo ini: 

{{< youtube fjwIyGWjKrg >}}

<br>

Video ini menyarankan untuk meniup lubang didekat kipas 
pendingin (Cooling Fan).

Saya coba hidupkan lagi, masih saja belum bisa.

Kemudian saya coba periksa kipas pendinginnya.

Ternyta kipasnya tidak mau bergerak kerena banyak debu.

Lalu saya bersihkan sampai kipas tersebut bisa bergerak dengan lancar.

Akhirnya laptop bisa hidup kembali. 😊 

Syukurlah...