---
title: "About Me"
slug: about
date: 2017-12-17T19:50:57+08:00
draft: false

type: page

image: "/img/about-me.jpg"
description: "Hello, Saya Dian. Salam kenal!"
---

![About Ardianta](/img/about-me.jpg)

Hello, nama saya **Ahmad Muhar Dian Lasmita**, disingkat ARDIANTA.
Sering dipanggil **Dian** (di rumah) dan **Pargo** (di sekolah).

<!-- Pengguna GNU/Linux sejak tahun 2011 hingga saat ini. Sehari-hari menggunakan GNU/Linux untuk pemrograman, desain, dan menulis. -->

Saat ini, saya adalah seorang mahasiswa Teknik Informatika di 
salah satu perguruan tinggi swasta di kota Mataram.

Pernah bersekolah di [SMK Negeri 2 Kuripan](http://www.smkn2kuripan.sch.id/) dengan jurusan TKJ
(Teknik Komputer & Jaringan).

Kontak yang bisa dihubungi:

- Email: <a href="mailto:dian@petanikode.com">dian@petanikode.com</a>
- WA/Telegram: +6287866866694
