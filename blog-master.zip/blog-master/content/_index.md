---
title: "Ardianta - Ahmad Muhar Dian Lasmita"
date: 2018-01-25T20:12:09+08:00
draft: false

type: page

image: ""
description: "Blog ini adalah blog pribadi yang isinya berupa catatan bebas. Namun, sepertinya akan lebih banyak catatan tentang dunia IT."
---

<!-- Hello, nama saya **Ahmad Muhar Dian Lasmita**, disingkat ARDIANTA.
Sering dipanggil **Dian** (di rumah) dan **Pargo** (di sekolah). -->

Blog ini adalah blog pribadi tempat mencatat segala hal yang ingin saya catat.
Buat kamu yang tertarik mengikuti update dari blog ini, bisa berlangganan
[RSS Feed](http://feeds.feedburner.com/ardianta)-nya atau ikuti saya di [Twitter](https://twitter.com/ardiantapargo) dan [Github](https://github.com/ardianta).